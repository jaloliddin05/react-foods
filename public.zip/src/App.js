import React from "react";
import "./App.css";
import Header from "./components/header";

function App() {
  return (
    <div className="App">
      <Header />
      <div className="bgDark"></div>
    </div>
  );
}

export default App;
