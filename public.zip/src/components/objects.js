const fastFoods = [
  {
    id: "1",
    img: "https://images.pexels.com/photos/1633578/pexels-photo-1633578.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
    price: 11.5,
    name: "Hamburger",
  },
  {
    id: "2",
    img: "https://images.pexels.com/photos/1552635/pexels-photo-1552635.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
    price: 15.5,
    name: "Pizza",
  },
  {
    id: "3",
    img: "https://images.pexels.com/photos/5112594/pexels-photo-5112594.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
    price: 9.5,
    name: "sandwich",
  },
  {
    id: "4",
    img: "https://images.pexels.com/photos/1893555/pexels-photo-1893555.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
    price: 4.5,
    name: "Fries",
  },
  {
    id: "5",
    img: "https://images.pexels.com/photos/4518655/pexels-photo-4518655.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500",
    price: 11.5,
    name: "Hot-Dog",
  },
  {
    id: "6",
    img: "https://media.istockphoto.com/photos/fast-food-doner-kebab-with-meat-vegetables-and-french-fries-picture-id502706186?k=20&m=502706186&s=612x612&w=0&h=WHAyFia6ut-ozC5FpUDOyl8TzjBroJh4fK6Tkg2tb3Y=",
    price: 12.5,
    name: "Donar Kebab",
  },
  {
    id: "7",
    img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQY511_0pSr4aQcjUBekxbfFWaN_gqO4nRdvg&usqp=CAU",
    price: 7.6,
    name: "Kfs",
  },
  {
    id: "8",
    img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTUItkKQgTL5sOX6a8j9D2On0HNL0Dux2eBXQ&usqp=CAU",
    price: 10.7,
    name: "Lavash",
  },
  {
    id: "9",
    img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTi2WbtdzmgX7S7Psn-UhLed9OlVLBb6UFyTQ&usqp=CAU",
    price: 9.5,
    name: "Cheese Burger",
  },
  {
    id: "10",
    img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTqvgrvq-dhClWXTGP0QKj2bbXd6Zp3qqQnpw&usqp=CAU",
    price: 8.5,
    name: "Bread Kebab",
  },
];

export default fastFoods;
