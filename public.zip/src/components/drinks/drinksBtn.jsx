import React from "react";

const Drinksbtn = ({ changeDrink, setDrink, setDropDown }) => {
  return (
    <button
      className="nav_menu"
      onClick={() => {
        setDrink(!changeDrink);
        setDropDown(true);
      }}
    >
      Drinks
    </button>
  );
};

export default Drinksbtn;
