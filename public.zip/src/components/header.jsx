import React, { useContext, useState } from "react";
import "./header.css";
import img_logo from "../images/Mcdonalds.svg";
import Foods from "./foods";
import MoneyBtn from "./buttons/money_btn";
import FoodBtn from "./buttons/food_btn";
import Drinks from "./drinks/drinks";
import Drinksbtn from "./drinks/drinksBtn";

const Header = () => {
  const [dropDown, setDropDown] = useState(true);
  const [changeDrink, setDrink] = useState(true);
  return (
    <header className="header">
      <div className="container">
        <a href="#" className="logo_link">
          <img
            src={img_logo}
            alt=""
            width={60}
            height={60}
            className="site_logo"
          />
        </a>
        <nav className="nav">
          <ul className="nav_list">
            <li className="nav_item">
              <FoodBtn
                dropDown={dropDown}
                setDropDown={setDropDown}
                setDrink={setDrink}
              />
            </li>
            <li className="nav_item">
              <Drinksbtn
                changeDrink={changeDrink}
                setDrink={setDrink}
                setDropDown={setDropDown}
              />
            </li>
            <li className="nav_item">
              <button className="nav_menu">Orders</button>
            </li>
            <li className="nav_item">
              <MoneyBtn />
            </li>
          </ul>
        </nav>
      </div>
      <>
        <Foods change={dropDown} />
        <Drinks changeDrink={changeDrink} />
      </>
    </header>
  );
};

export default Header;
