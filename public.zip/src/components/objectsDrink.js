const drinks = [
  {
    id: "11",
    img: "https://images.unsplash.com/photo-1473115209096-e0375dd6b3b3?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTk4fHxkcmlua3xlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60",
    price: 6.5,
    name: "Milk Creme Chocolate",
  },
  {
    id: "12",
    img: "https://images.unsplash.com/photo-1504123221345-938396029ff2?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MjY4fHxkcmlua3xlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60",
    price: 7.25,
    name: "Dessert Creme",
  },
  {
    id: "13",
    img: "https://images.unsplash.com/photo-1457518919282-b199744eefd6?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MzM0fHxkcmlua3xlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60",
    price: 3.25,
    name: "Ice blackberry tea",
  },
  {
    id: "14",
    img: "https://images.unsplash.com/photo-1569161238483-4c6375c59d68?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MzQ5fHxkcmlua3xlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60",
    price: 4.25,
    name: "Coffee Espresso",
  },
  {
    id: "15",
    img: "https://media.istockphoto.com/photos/delicious-freshly-squeezed-orange-juice-from-organic-oranges-from-the-picture-id1282705707?b=1&k=20&m=1282705707&s=170667a&w=0&h=KZ34-pSLkKo3vRoZV3yMkTBLpOLdRthmIxj0kTpMXTI=",
    price: 3.2,
    name: "Fanta",
  },
  {
    id: "16",
    img: "https://images.unsplash.com/photo-1593715758817-31ec545caaff?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MzMwfHxjb2NhJTIwY29sYXxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60",
    price: 3.2,
    name: "Coca Cola",
  },
  {
    id: "17",
    img: "https://images.unsplash.com/photo-1629203849820-fdd70d49c38e?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8cGVwc2l8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60",
    price: 3.2,
    name: "Pepsi",
  },
  {
    id: "18",
    img: "https://images.unsplash.com/photo-1564890369478-c89ca6d9cde9?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8dGVhfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60",
    price: 2.2,
    name: "Green tea",
  },
  {
    id: "19",
    img: "https://images.unsplash.com/photo-1579954115545-a95591f28bfc?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8OTR8fGRyaW5rfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60",
    price: 5.45,
    name: "Kokteyl with strawberry",
  },
  {
    id: "20",
    img: "https://images.unsplash.com/photo-1623934397237-ce68cb0285b3?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8OTd8fGRyaW5rfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60",
    price: 5.45,
    name: "Ice apelsin juce",
  },
];
export default drinks;
