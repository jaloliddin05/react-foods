import React from "react";
import "./header_btn.css";

const FoodBtn = ({ dropDown, setDropDown, setDrink }) => {
  return (
    <>
      <button
        onClick={() => {
          setDropDown(!dropDown);
          setDrink(true);
        }}
        className="nav_menu"
      >
        Foods
      </button>
    </>
  );
};

export default FoodBtn;
